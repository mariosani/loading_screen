Config = {}; // Don't touch

Config.ServerIP = "YOUR IP SERVER";

// Social media buttons on the left side
Config.Socials = [
    {name: "discord", label: "Discord Gang Sebelah Roleplay", description: "Click here to copy the link and join our Discord server!", icon: "assets/media/icons/discord.png", link: "https://discord.gg/FkSqJFHHWy"},
    {name: "web", label: "Web Gang Sebelah Roleplay", description: "An Instagram page will open for us soon, feel free to join and follow us!", icon: "assets/media/icons/tiktok.png", link: "#"},
    {name: "discord", label: "Discord Gang Sebelah", description: "Click here to copy the link and join our Discord server!", icon: "assets/media/icons/discord.png", link: "https://discord.gg/uhscvmnfGU"},
    {name: "web", label: "Web Gang Sebelah ", description: "An Instagram page will open for us soon, feel free to join and follow us!", icon: "assets/media/icons/tiktok.png", link: "#"},
    {name: "donet", label: "Donations", description: "For donations, feel free to look at the room - #Donations at Discord.", icon: "assets/media/icons/bca.png", link: "https://discord.gg/FkSqJFHHWy"},
];

Config.HideoverlayKeybind = 112 // JS key code https://keycode.info
Config.CustomBindText = "F1"; // leave as "" if you don't want the bind text in html to be statically set

// Staff list
Config.Staff = [
    {name: "REX ++", description: "Dev", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001536332063051946/Desain_tanpa_judul_11.png"},
    {name: "MARIO", description: "Dev", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001522737958895797/Desain_tanpa_judul_10.png"},
    {name: "AGUS", description: "Owner", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001522094313570455/Desain_tanpa_judul_8.png"},
    {name: "DIMAS", description: "Owner", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001518639498919956/filled-logo.png"},
    {name: "MUN QUAKE", description: "Admin", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001518639498919956/filled-logo.png"},
    {name: "ABEY", description: "Admin", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/606065181151330305/1001518639498919956/filled-logo.png"},
    {name: "SYNDLE", description: "Admin", color: "#ff0000", image: "https://cdn.discordapp.com/attachments/1001525794717311047/1001525839327932566/FB_IMG_1658852592769.jpg"},

];

// Categories
Config.Categories = [
    {label: "Social Media", default: true},
    {label: "Staff", default: false}
];

// Music
Config.Song = "song.mp3";